/**
 * Aura Promote order receiver.
 * 1) Create a Google Sheet.
 * 2) Extensions > Apps Script, paste this code.
 * 3) Deploy > New deployment > Web app.
 *    Execute as: Me
 *    Who has access: Anyone (needed for public order form)
 * 4) Copy the Web app URL into CONFIG.APPS_SCRIPT_URL in index.html.
 *
 * Keep customer data private. Do not collect payment PINs or OTPs.
 */
const SHEET_NAME = "Orders";
const HEADERS = [
  "Submitted At", "Order ID", "Customer", "TikTok Video URL", "Package ID",
  "Package Name", "Price BDT", "Audience", "Contact", "Payment Method",
  "Transaction ID", "Customer Note", "Status"
];

function doGet() {
  return ContentService.createTextOutput("Aura Promote order endpoint is running.");
}

function doPost(e) {
  try {
    if (!e || !e.postData || !e.postData.contents) {
      return json_({ ok: false, message: "Missing order data" });
    }
    const data = JSON.parse(e.postData.contents);
    const required = ["customer", "video", "packageId", "packageName", "price", "contact", "payment", "trx"];
    required.forEach(function(key) {
      if (data[key] === undefined || data[key] === null || String(data[key]).trim() === "") {
        throw new Error("Missing field: " + key);
      }
    });
    if (!/^https:\/\/(www\.)?(tiktok\.com|vm\.tiktok\.com|vt\.tiktok\.com)\//i.test(String(data.video))) {
      throw new Error("Invalid TikTok URL");
    }
    if (String(data.customer).length > 80 || String(data.note || "").length > 500) {
      throw new Error("Field too long");
    }
    const allowedPayments = ["bKash", "Nagad"];
    if (allowedPayments.indexOf(String(data.payment)) === -1) throw new Error("Invalid payment method");

    const lock = LockService.getScriptLock();
    lock.waitLock(10000);
    try {
      const sheet = getSheet_();
      const orderId = "AURA-" + Utilities.formatDate(new Date(), Session.getScriptTimeZone(), "yyyyMMdd-HHmmss") +
                      "-" + Math.floor(100 + Math.random() * 900);
      // Prefix user-provided strings to prevent spreadsheet formula injection.
      const row = [
        new Date(),
        orderId,
        safeCell_(data.customer),
        safeCell_(data.video),
        safeCell_(data.packageId),
        safeCell_(data.packageName),
        Number(data.price),
        safeCell_(data.age || ""),
        safeCell_(data.contact),
        safeCell_(data.payment),
        safeCell_(data.trx),
        safeCell_(data.note || ""),
        "Pending payment verification"
      ];
      sheet.appendRow(row);
      return json_({ ok: true, orderId: orderId });
    } finally {
      lock.releaseLock();
    }
  } catch (err) {
    console.error(err);
    return json_({ ok: false, message: "Order could not be saved" });
  }
}

function getSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) sheet = ss.insertSheet(SHEET_NAME);
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(HEADERS);
    sheet.setFrozenRows(1);
    sheet.getRange(1, 1, 1, HEADERS.length).setFontWeight("bold");
  }
  return sheet;
}

function safeCell_(value) {
  const s = String(value == null ? "" : value).trim();
  return /^[=+\-@]/.test(s) ? "'" + s : s;
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
