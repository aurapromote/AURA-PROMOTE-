# Aura Promote — free starter website

## Included
- `index.html`: responsive Bengali/English landing page, service cards, editable package cards, order form, manual bKash/Nagad instructions.
- `Code.gs`: Google Apps Script endpoint that appends orders to a Google Sheet.
- `README.md`: setup and safety notes.

## A. Set up the order spreadsheet
1. Sign in to your Google account and create a new Google Sheet named `Aura Promote Orders`.
2. In the sheet, open **Extensions → Apps Script**.
3. Replace the editor contents with `Code.gs` from this package.
4. Save the project.
5. Choose **Deploy → New deployment → Web app**.
6. Set **Execute as** to your account. Set access to **Anyone** only if you intend to accept public orders. This makes the endpoint public; do not store secrets in the script.
7. Deploy and authorize it. Copy the Web app URL ending in `/exec`.

## B. Configure the website
Open `index.html` in a text editor and find the `CONFIG` object near the bottom:
- Replace `PASTE_YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL_HERE` with the deployed `/exec` URL.
- Replace `আপনার bKash নম্বর বসান` and `আপনার Nagad নম্বর বসান` with the business payment numbers you intend to use.
- Edit `packages` prices/quantities to match your actual service.
Do not collect PINs, passwords, or OTPs. Never publish your personal payment number unless you intend customers to use it.

## C. Publish for free
Simplest option for a beginner: use a static hosting provider that offers a free plan, such as Cloudflare Pages.
1. Create a Git repository and upload `index.html` (or follow the host's direct-upload instructions if available).
2. Create a Pages project and deploy the site.
3. Use the free project URL. A custom domain is optional and usually costs money.
4. Test on your phone with a small test order. Confirm the row appears in the Google Sheet.

Official docs:
- Apps Script HTML/web apps: https://developers.google.com/apps-script/guides/web
- Apps Script HTML service: https://developers.google.com/apps-script/guides/html
- Cloudflare Pages limits: https://developers.cloudflare.com/pages/platform/limits/

## Order management
Orders appear in the `Orders` tab. Use the `Status` column to update states, e.g.:
- Pending payment verification
- Payment verified
- In progress
- Completed
- Rejected / refunded

Verify the actual bKash/Nagad transaction in your account before marking an order as paid. The browser cannot securely confirm payment automatically in this manual setup.

## Important limitations
- This starter is not an automatic payment gateway.
- The form uses `no-cors` to submit to Apps Script; browser success does not prove the row was saved. Check the Sheet for each order.
- Anyone who has the public form can submit data, so spam protection and stricter server-side validation may be needed if the site grows.
- This starter does not include customer accounts, a wallet, automatic refunds, or automatic delivery of promotion services.
- Be transparent about expected results; views/likes cannot be guaranteed. Follow platform rules and applicable laws.
